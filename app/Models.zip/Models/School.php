<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class School extends Model
{
    use HasFactory;
    protected $table = "schools";
    protected $primarykey = "id";
    protected $fillable = ['id','school_name','school_address','year_establish','incharge_name','email','contact_number','kidspreneurship_representative','course_start_date','create_entrepreneurship','weekly_class_time','	package','school_logo','upload_excel'];

    // public function trainer(){
    //     return $this->belongsTo(Trainer::class, "id");
    // }
}
