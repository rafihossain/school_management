<?php

namespace App\Http\Controllers\Backend;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Setting;
use App\Models\school;
use App\Models\grade;
use App\Models\Trainer;
use App\Models\User;
use Auth;
use Log;
use File;
use Image;
use DB;
use Hash;

class TrainerController extends Controller
{
    public function addTrainer(){
        
       return view('backend.trainer.add_trainer');
    }

    public function storeTrainer(Request $request){
        
        $validated = $request->validate([
            'trainer_name' => 'required',
            'email' => 'required',
            'trainer_fee' => 'required',
            'contact_no' => 'required',
        ]);

        // Image upload 
        // $request_image = $request->file('image');
        // $image = Image::make($request_image);
        // $image_path = public_path('/image/trainer/');
        // $img_name = time().'.'.$request_image->getClientOriginalExtension();
        // $image->save($image_path.$img_name);

        // $image_name = $image_path."thumbnail/".$img_name;
        // $image->resize(null, 200, function($constraint) {
        //     $constraint->aspectRatio();
        // });
         
        // $image->save($image_name);
        
        $user = new User;
        $user->name = $request->trainer_name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->group = 3;
        $user->save();

        $user_id = DB::getPdo()->lastInsertId();
        
        
        $trainer= new trainer;
        $trainer->user_id = $user_id;
        $trainer->trainer_name = $request->trainer_name;
        $trainer->email= $request->email;
        $trainer->trainer_fee= $request->trainer_fee;
        $trainer->contact_no= $request->contact_no;
        $trainer->save();

        return redirect()->route('backend.trainerlist.trainerList')->with('success', 'Data Stored successfully.');
    }

    public function trainerList(){
        $trainers = Trainer::get()->toArray();
        return view('backend.trainer.trainer_list')->with('trainers',$trainers);
    }

    public function trainerEdit($id){
        $schools = school::select('*')->get();
        $grades = grade::select('*')->get();

        $trainer = Trainer::find($id)->toArray();

       return view('backend.trainer.edit_trainer')->with('schools',$schools)->with('grades',$grades)->with('trainer',$trainer); 
    }

    public function updateTrainer(Request $request){

        $validated = $request->validate([
            'trainer_name' => 'required',
            'email' => 'required',
            'contact_no' => 'required',
            'address' => 'required',
            'city' => 'required',
            'address' => 'required',
            'join_date' => 'required',
            'date_of_birth' => 'required',
            'image' => 'required',
            'mode' => 'required',
            'type' => 'required',
            'no_of_hour_per_week' => 'required',

        ]);


        $request_image = $request->file('image');
        
        if(!empty($request_image)){

        $image = Image::make($request_image);
        $image_path = public_path('/image/trainer/');
        $img_name = time().'.'.$request_image->getClientOriginalExtension();
        $image->save($image_path.$img_name);

        $image_name = $image_path."thumbnail/".$img_name;
        $image->resize(null, 200, function($constraint) {
            $constraint->aspectRatio();
        });
         
        $image->save($image_name);
        }else{
            $image_name = $request->pre_image;
        }

        $user= User:: find($request->user_id)->toArray();

        if(!empty($user)){
            echo "hello1";die();
            if($user['email']==$request->email && $user['id']==$request->user_id){
                echo "hello111";die();
                $user= User:: find($request->user_id);
                $user->name = $request->trainer_name;
                $user->email = $request->email;
                $user->save();
            }
        }

     
        
        $trainer= trainer:: find($request->id);
        $trainer->trainer_name = $request->trainer_name;
        $trainer->email= $request->email;
        $trainer->contact_no= $request->contact_no;
        $trainer->address= $request->address;
        $trainer->city= $request->city;
        $trainer->join_date = $request->join_date;
        $trainer->date_of_birth= $request->date_of_birth;
        $trainer->image = $image_name;
        $trainer->mode= $request->mode;
        $trainer->type = $request->type;
        $trainer->no_of_hour_per_week = $request->no_of_hour_per_week;
        $trainer->save();

        return redirect()->route('backend.trainerlist.trainerList')->with('update_success', 'Data Updated successfully.');
    }

    public function trainerDelete($id){
        $data = Trainer :: find($id);
        if(!is_null($data)){
            $data->delete();
        }
        return redirect()->route('backend.trainerlist.trainerList')->with('update_success', 'Data deleted successfully.');
    }

}