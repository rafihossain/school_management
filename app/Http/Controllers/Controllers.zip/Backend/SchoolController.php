<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\School;
use App\Models\User;
use App\Models\Grade;
use App\Models\EmailNotification;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use DB;
use File; 


class SchoolController extends Controller
{
    public function schoolCreate()
    {
        $grade=Grade::all();
        return view('backend.school.add_school',compact('grade'));
    }

    public function schoolStore(Request $req)
    {

        $validatedData = $req->validate([
            'school_name' => 'required',
            'principle_name' => 'required',
            'country' => 'required',
            'membership_plan' => 'required',
            'official_email_id' => 'required|unique:schools',
            'contact_number' => 'required',

        ]);

        $user=New User;
        $password=Str::random(6);
        $email=$req->official_email_id;
        $user->email=$email;
        $user->password=Hash::make($password); 
        $user->group=2;
        $user->save();
        $user_id=$user->id;
       
        $data=array();
		$data['school_name']=$req->school_name;
        $data['principle_name']=$req->principle_name;
        $data['country']=$req->country;
        $data['official_email_id']=$email;
        $data['contact_number']=$req->contact_number;
        $data['membership_plan']=$req->membership_plan;
        $data['user_id']=$user_id;    

        // $school_logo=$req->school_logo;
        // $excel_file=$req->upload_excel;
   
        // if($school_logo)
        // {
        //     $image_name=Str::random(10);//unique nmae generate every time
        //     $ext=strtolower($school_logo->getClientOriginalExtension());
        //     $image_full_name='school_'.$image_name.'.'.$ext;

        //     $upload_path='image/school/';
            
        //     $success=$school_logo->move($upload_path,$image_full_name);

        //     $data['school_logo']=$upload_path.$image_full_name;
        // }

        // if($excel_file)
        // {
        //     $excel_name=Str::random(10);//unique nmae generate every time
        //     $ext=strtolower($excel_file->getClientOriginalExtension());
        //     $image_full_name='excel_'.$excel_name.'.'.$ext;

        //     $upload_path='image/school/excel/';
            
        //     $success=$excel_file->move($upload_path,$image_full_name);

        //     $data['upload_excel']=$upload_path.$image_full_name;
        // }

        // $student_grade['grade3_student']=$req->grade3_student;
        // $student_grade['grade4_student']=$req->grade4_student;
        // $student_grade['grade5_student']=$req->grade5_student;
        // $student_grade['grade6_student']=$req->grade6_student;
        // $student_grade['grade7_student']=$req->grade7_student;
        // $student_grade['grade8_student']=$req->grade8_student;
        // $student_grade['grade9_student']=$req->grade9_student;
        // $student_grade['grade10_student']=$req->grade10_student;
        // $student_grade['grade11_student']=$req->grade11_student;
        $student_grade=$req->number_of_student;
        $i=1;
        $grade='grade';
        $all_grade=array();
        foreach($student_grade as $grade_value)
        {
            $all_grade[$i]=$grade_value;
            $i++;
        }
       
        $new=json_encode($all_grade);
        
        

        $data['number_of_student']=$new;
        $success=DB::table('schools')->insert($data);
        

        //Start Email send section-----
        $notification=EmailNotification::find(1)->toArray(); 
        
        $change=["{app_name}","{receiver_name}","{email}","{pass}"];
        $change_to=['kidspreneurship',$data['school_name'],$email,$password];
        $email_body=str_replace($change,$change_to,$notification['mail_body']);
         
        file_put_contents('../resources/views/mail.blade.php',$email_body);


        $data = array('email'=>$email,'subject'=>$notification['mail_sub']);

      
        Mail::send('mail', $data, function($message) use ($data){
            $message->to($data['email'], 'Tutorials Point')->subject
               ($data['subject']);
         });

         /*End  Email section */

       if($success)
       {
            $notification=array(
                'message'=>'School successfully Inserted!',
                'success'=>'success',
            );

            return redirect()->route('backend.schoollist.schoolList')->with($notification);
       }

        
        
    }

    public function schoolList()
    {
        $school_list=School::all();
        // echo '<pre>';
        // print_r($school_list);
        // die();
        return view('backend.school.school_list',compact('school_list'));
    }

    public function schoolEdit($id)
    {
       $school=School::find($id);
       $grade=Grade::all();
    //    echo '<pre>';
    //    print_r($grade);
    //    die(); 
       return view('backend.school.edit_school',compact('school','grade'));
    }

    public function schoolUpdate(Request $req)
    {
        $schhol_id=$req->school_id;
        $email=$req->school_email;

        $validatedData = $req->validate([
            'school_name' => 'required',
            'address' => 'required',
            'year_establish' => 'required',
            'incharge_name' => 'required',
            'email' => 'required',
            'contact_number' => 'required',

        ]);


        
        $data=array();
		$data['school_name']=$req->school_name;
        $data['school_address']=$req->address;
        $data['year_establish']=$req->year_establish;
        $data['incharge_name']=$req->incharge_name;
        $data['incharge_email']=$req->incharge_email;
        $data['contact_number']=$req->contact_number;
        $data['kidspreneurship_representative']=$req->partner_name;
        $data['course_start_date']=$req->course_start_date;
        //$data['create_entrepreneurship']=$req->radio1;
        //$data['weekly_class_time']=$req->weekly_class_time;
        $data['membership_plan']=$req->membership_plan;

        $school_logo=$req->school_logo;
        $excel_file=$req->upload_excel;

        $old_school_logo=$req->old_school_logo;
        $old_excel_file=$req->old_excel;

        if($school_logo){

			if(File::exists($old_school_logo)){
				unlink($old_school_logo);
			}

            $image_name=Str::random(10);//unique nmae generate every time
            $ext=strtolower($school_logo->getClientOriginalExtension());
            $image_full_name='school_'.$image_name.'.'.$ext;

            $upload_path='image/school/';
            
            $success=$school_logo->move($upload_path,$image_full_name);

            $data['school_logo']=$upload_path.$image_full_name;

        }

        if($excel_file)
        {
           
            $excel_name=Str::random(10);//unique nmae generate every time
            $ext=strtolower($excel_file->getClientOriginalExtension());
            $image_full_name='excel_'.$excel_name.'.'.$ext;

            $upload_path='image/school/excel/';
            
            $success=$excel_file->move($upload_path,$image_full_name);

            $data['upload_excel']=$upload_path.$image_full_name;
        }

        
        // $student_grade['grade3_student']=$req->grade3_student;
        // $student_grade['grade4_student']=$req->grade4_student;
        // $student_grade['grade5_student']=$req->grade5_student;
        // $student_grade['grade6_student']=$req->grade6_student;
        // $student_grade['grade7_student']=$req->grade7_student;
        // $student_grade['grade8_student']=$req->grade8_student;
        // $student_grade['grade9_student']=$req->grade9_student;
        // $student_grade['grade10_student']=$req->grade10_student;
        // $student_grade['grade11_student']=$req->grade11_student;
        // $student_grade['grade12_student']=$req->grade12_student;
        // $new=json_encode($student_grade);

        // $data['school_grade']=$new;

        $student_grade=$req->number_of_student;
        $i=1;
        $grade='grade';
        $all_grade=array();
        foreach($student_grade as $grade_value)
        {
            $all_grade[$i]=$grade_value;
            $i++;
        }
       
        $new=json_encode($all_grade);
        
        

        $data['number_of_student']=$new;
        // echo '<pre>';
        // print_r($data);
        // die();
        //$school_update=School::first($schhol_id);
        $success=School::where("id",$schhol_id)->update($data);

        //Start Email send section-----
        $notification=EmailNotification::find(10)->toArray(); 

        $change=["{app_name}","{receiver_name}","{action_by}"];
        $change_to=['kidspreneurship',$data['school_name'],"Super admin"];
        $email_body=str_replace($change,$change_to,$notification['mail_body']);

        file_put_contents('../resources/views/mail.blade.php',$email_body);


        $data = array('email'=>$data['incharge_email'],'subject'=>$notification['mail_sub']);

      
        Mail::send('mail', $data, function($message) use ($data){
            $message->to($data['email'], 'Tutorials Point')->subject
               ($data['subject']);
         });

         /*End  Email section */

        if($success)
        {
             $notification=array(
                 'message'=>'School successfully Updated!',
                 'success'=>'success',
             );
 
             return redirect()->route('backend.schoollist.schoolList')->with($notification);
        }

    }

    public function schoolDelete($id)
    {
        $data=School::find($id);

  
       
        if($data->school_logo)
        {

            if(File::exists($data->school_logo)){
                unlink($data->school_logo);
            }
        }
        if($data->upload_excel)
        {
            if(File::exists($data->upload_excel)){
                unlink($data->upload_excel);
            }
        }
        //echo $data->user_id;die();
        $user=User::where('id',$data->user_id)->first();
       
		$success=School::where('id',$id)->delete();

        if($success)
        {
            $notification=array(
                'message'=>'School Successfully deleted!',
                'success'=>'success',
            );
            return redirect()->back()->with($notification);
        }
		
    }
}