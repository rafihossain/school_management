<li class="breadcrumb-item"><a href="{{route('backend.dashboard')}}"><i class="c-icon cil-speedometer"></i> {{__('Dashboard')}}</a></li>

{!! $slot !!}
