                                                                      <p><img src="http://schoolmanagement.com/image/school.png" alt="app_logo" height="50px" style=""></p><p>Hi Aline Wilson</p>
<p>Hope this mail finds you well and healthy. We are informing you that you've been edited school to our application by Super admin. It'll be a great opportunity to work with you.<br>
Thanks &amp; Regards,
kidspreneurship 
</p>                                          