@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">{{__('admin.edit_school')}}</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">{{__('admin.home')}}</a></li>
              <li class="breadcrumb-item active">{{__('admin.add_school')}}</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
             
        <div class="row">
           <div class="col-md-6">
              <div class="card card-primary">
                 <div class="card-header">
                  
                 </div>
            
                 <form action="{{route('backend.schoolupdate.schoolUpdate')}}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <?php 
                     $grade_decode=json_decode($school->number_of_student,true);
                     // echo '<pre>';
                     // print_r($grade_decode);
                     // die();
                    ?>
                    <input type="hidden" value="{{$school->id}}" name="school_id">
                    <input type="hidden" value="{{$school->email}}" name="school_email">
                    <input type="hidden" value="{{$school->school_logo}}" name="old_school_logo">
                    <input type="hidden" value="{{$school->upload_excel}}" name="old_excel">
                    <div class="card-body">
                       <div class="form-group">
                          <label for="schoolname">{{__('admin.school_name')}}</label>
                          <input type="text" class="form-control @error('school_name') is-invalid @enderror" id="schoolname" name="school_name" value="{{$school->school_name}}">
                          @error('school_name')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="schoolname">{{__('admin.address')}}</label>
                          <textarea type="text" class="form-control @error('address') is-invalid @enderror" id="address" placeholder="" name="address">{{$school->school_address}}</textarea>
                          @error('address')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="yearestablished">{{__('admin.year_established')}}</label>
                          <input type="number" class="form-control @error('year_establish') is-invalid @enderror" id="yearestablished" placeholder="" min="0" name="year_establish" value="{{$school->year_establish}}">
                          @error('year_establish')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>


                       <div class="form-group">
                          <label for="schoolname">{{__('admin.number_of_student')}}</label>
                          <?php $i=1;?>
                         @foreach($grade as $grades) 
                          <div class="input-group mb-3">
                             <div class="input-group-prepend">
                                <span class="input-group-text">{{$grades->grade}}</span>
                             </div>         
                           
                             <input type="number" class="form-control" placeholder="" name="number_of_student[]" value="{{$grade_decode[$i]}}">
                          </div>
                         <?php $i++; ?>
                        @endforeach  
                       </div>

                       
                       <div class="form-group">
                          <label for="inchargename">{{__('admin.activity_in_charge_name')}}</label>
                          <input type="text" class="form-control @error('incharge_name') is-invalid @enderror" id="inchargename" name="incharge_name" placeholder="" value="{{$school->incharge_name}}">
                          @error('incharge_name')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargeemail">{{__('admin.in_charge_email')}}</label>
                          <input type="text" class="form-control @error('incharge_email') is-invalid @enderror" id="inchargeemail" name="incharge_email" placeholder="" value="{{$school->incharge_email}}">
                          @error('incharge_email')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>


                        <div class="form-group">
                          <label for="inchargecontact">{{__('admin.in_charge_contact_number')}}</label>
                          <input type="number" class="form-control @error('contact_number') is-invalid @enderror" name="contact_number" id="inchargecontact" placeholder="" min="0" value="{{$school->contact_number}}">
                          @error('contact_number')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                        </div>

                        <div class="form-group">
                          <label for="partnername">Kidspreneurship Representative</label>
                          <input type="text" class="form-control" id="partnername" name="partner_name" placeholder="" value="{{$school->kidspreneurship_representative}}">
                        </div>
                      </div>
                
              </div>
              
           </div>
            
             <div class="col-md-6">
              <div class="card card-warning">
                 <div class="card-header">
                  
                 </div>
          
                    <div class="card-body">
                       <div class="form-group">
                          <label for="exampleInputFile">{{__('admin.school_logo')}}</label>
                          <div class="input-group">
                             <div class="custom-file">
                                <input type="file" class="custom-file-input" id="exampleInputFile" name="school_logo">
                                <label class="custom-file-label" for="exampleInputFile">{{__('admin.choose_file')}}</label>
                             </div>
                             <div class="input-group-append">
                                <span class="input-group-text">{{__('admin.upload')}}</span>
                             </div>
                          </div>
                        </div>

                        <div class="form-group">
                          <label for="exampleInputFile">{{__('admin.upload_excel')}}</label>
                          <div class="input-group">
                             <div class="custom-file">
                                <input type="file" class="custom-file-input" id="exampleInputFile" name="upload_excel">
                                <label class="custom-file-label" for="exampleInputFile">{{__('admin.choose_file')}}</label>
                             </div>
                             <div class="input-group-append">
                                <span class="input-group-text">{{__('admin.upload')}}</span>
                             </div>

                          </div>
                          <a href="#" class="text-danger">Upload Excel file</a>
                        </div>

                       <div class="form-group">
                          <label for="schoolname">{{__('admin.course_start_date')}}</label>
                          <input type="date" class="form-control" id="startdate" name="course_start_date" placeholder="" value="{{$school->course_start_date}}">
                       </div>
<!-- 
                       <div class="form-group">
                          <label for="yearestablished">{{__('admin.create_an_entrepreneurship')}}</label>
                         
                              

                              <div class="row">
                               <div class="form-check col-md-4">

                                  <input class="form-check-input" type="radio" name="radio1" value="yes" @if($school->create_entrepreneurship == 'yes') checked @endif>
                                  <label class="form-check-label">{{__('admin.yes')}}</label>
                               </div>

                               <div class="form-check col-md-4">
                                  <input class="form-check-input" type="radio" name="radio1" value="no" @if($school->create_entrepreneurship == 'no') checked @endif>
                                  <label class="form-check-label">{{__('admin.no')}}</label>
                               </div>

                               <div class="form-check col-md-4">
                                  <input class="form-check-input" type="radio" name="radio1" value="maybe" @if($school->create_entrepreneurship == 'maybe') checked @endif>
                                  <label class="form-check-label">{{__('admin.maybe')}}</label>
                               </div>
                              </div>
                              
                         
                       </div> -->

                       <div class="form-group">
                          <label for="schoolname">{{__('admin.time_for_weekly_classes')}}</label>
                          <!-- <input type="date"  name="weekly_class_time" class="form-control" data-date-inline-picker="true" value="{{$school->weekly_class_time}}" /> -->
                       </div>
                        <div class="form-group">
                          <label for="package">{{__('admin.select_package')}}</label>
                          <select class="form-control" name="membership_plan">
                            <option value="">---{{__('admin.select_package')}}---</option>
                            <option value="1"  @if($school->membership_plan == '1') selected @endif>Essential</option>
                            <option value="2"  @if($school->membership_plan == '2') selected @endif>Standard</option>
                            <option value="3"  @if($school->membership_plan == '3') selected @endif>Premium</option> 
                          </select>
                       </div>
                       

                      </div>

                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                      </div>
                 </form>
              </div>
              
           </div>

        </div>




        
        
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

  @endsection