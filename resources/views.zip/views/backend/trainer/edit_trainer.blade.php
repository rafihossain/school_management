@extends('backend.layouts.app')

@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Add Trainer</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add Trainer</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">

        <div class="row">
           <div class="col-md-6">
              <div class="card card-primary">
                 <div class="card-header">
                
                 </div>
                 <form action="{{ route('backend.updatetrainer.updateTrainer') }}" method="POST" enctype="multipart/form-data">
                     @csrf
                     
                    <div class="card-body">
                        <div class="form-group">

                          <input type="hidden" name="id" value="{{$trainer['id']}}">
                          <input type="hidden" name="user_id" value="{{$trainer['user_id']}}">

                          <label for="inchargename">Trainer Name</label>
                          <input type="text" class="form-control" id="inchargename" placeholder="" name="trainer_name" value="{{$trainer['trainer_name']}}">
                          @error('trainer_name')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                        </div>
                        <div class="form-group">
                          <label for="inchargeemail">Email Id</label>
                          <input type="email" class="form-control" id="inchargeemail" placeholder="" name="email" value="{{$trainer['email']}}">
                          @error('email')
                           <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                        </div>

                       <div class="form-group">
                          <label for="inchargecontact">Contact No</label>
                          <input type="text" class="form-control" id="inchargecontact" placeholder="" name="contact_no" value="{{$trainer['contact_no']}}">
                          @error('contact_no')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargeaddress">Address</label>
                          <input type="text" class="form-control" id="inchargeaddress" placeholder="" name="address" value="{{$trainer['address']}}">
                          @error('address')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargecity">Trainer City</label>
                          <input type="text" class="form-control" id="inchargecity" placeholder="" name="city" value="{{$trainer['city']}}">
                          @error('city')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargejoindate">Joining Date</label>
                          <input type="date" class="form-control" id="inchargejoindate" placeholder="" name="join_date" value="{{$trainer['join_date']}}">
                          @error('join_date')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                    </div>
             
              </div>
              
           </div>
            
             <div class="col-md-6">
              <div class="card card-warning">
                 <div class="card-header">
                  
                 </div>
           
                    <div class="card-body">
                      
                    
                       <div class="form-group">
                          <label for="dob">Date Of Birth</label>
                          <input type="date" class="form-control" id="dob" placeholder="" name="date_of_birth" value="{{$trainer['date_of_birth']}}">
                             @error('date_of_birth')
                                <strong class="text-danger">{{ $message }}</strong>
                             @enderror
                       </div>   
                       <div class="form-group">
                          <label for="exampleInputFile">Upload Identify Proof</label>
                          <div class="input-group">
                             <div class="custom-file">
                                <input type="file" class="custom-file-input" id="exampleInputFile" name="image">
                                <input type="text" name="pre_image" value="{{$trainer['image']}}">
                                <label class="custom-file-label" for="exampleInputFile">Choose file</label>
                             </div>
                             <div class="input-group-append">
                                <span class="input-group-text">Upload</span>
                             </div>
                          </div>
                             @error('image')
                                <strong class="text-danger">{{ $message }}</strong>
                             @enderror
                        </div> 

                       <div class="form-group">
                          <label for="mode">Mode</label>
                           <select class="form-control" name="mode">
                             <option value="1"<?php if($trainer['mode']==1){echo "selected";}?>
                             >Online</option>
                             <option value="2" <?php if($trainer['mode']==2){echo "selected";}?>>Offline</option>
                             <option value="3" <?php if($trainer['mode']==3){echo "selected";}?>>Both</option> 
                           </select>
                           @error('mode')
                                <strong class="text-danger">{{ $message }}</strong>
                           @enderror
                       </div>
                       <div class="form-group">
                          <label for="type">Type</label>
                           <select class="form-control" name="type">
                             <option value="1"<?php if($trainer['type']==1){echo "selected";}?>
                             >Full Time</option>
                             <option value="2" <?php if($trainer['type']==2){echo "selected";}?>>Per Time</option>
                             <option value="3" <?php if($trainer['type']==3){echo "selected";}?>>Industry</option>
                             <option value="3" <?php if($trainer['type']==4){echo "selected";}?>>Expert</option>
                             <option value="3" <?php if($trainer['type']==5){echo "selected";}?>>Other</option> 
                           </select>
                           @error('type')
                                <strong class="text-danger">{{ $message }}</strong>
                           @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargeno_of_hour_per_week">No. of hours per week</label>
                          <input type="text" class="form-control" id="inchargeno_of_hour_per_week" placeholder="" name="no_of_hour_per_week" value="{{$trainer['no_of_hour_per_week']}}">
                          @error('no_of_hour_per_week')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                      </div>

                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Update</button>
                      </div>
                 </form>
              </div>
              
           </div>

        </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@endsection
