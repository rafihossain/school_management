@extends('backend.layouts.app')


@section('content')
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Add Trainer</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Add Trainer</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">

        <div class="row">
           <div class="col-md-12">
              <div class="card card-primary">
                 <div class="card-header">
                
                 </div>
                 <form action="{{ route('backend.storetrainer.storeTrainer') }}" method="POST" enctype="multipart/form-data">
                     @csrf
                     
                    <div class="card-body">
                       <div class="form-group">
                          <label for="inchargename">Trainer Name</label>
                          <input type="text" class="form-control" id="inchargename" placeholder="" name="trainer_name">
                          @error('trainer_name')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargeemail">Email Id</label>
                          <input type="email" class="form-control" id="inchargeemail" placeholder="" name="email">
                          @error('email')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargefee">Trainer Fee (per hour)</label>
                          <input type="number" class="form-control" id="inchargefee" placeholder="" name="trainer_fee">
                          @error('trainer_fee')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>

                       <div class="form-group">
                          <label for="inchargecontact">contact_no</label>
                          <input type="text" class="form-control" id="inchargecontact" placeholder="" name="contact_no">
                          @error('contact_no')
                                <strong class="text-danger">{{ $message }}</strong>
                          @enderror
                       </div>
                       
                      </div>
                      <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                      </div>
                 </form>
             
              </div>
              
           </div>
            
        </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@endsection
